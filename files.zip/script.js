/* =========================================================
   SLICE CORNER — script.js
   All functionality is client-side only. Cart state lives in
   memory (a plain JS array) and resets on page reload, since
   this is a static demo with no backend/database.
   ========================================================= */

(function () {
  'use strict';

  /* ---------------------------------------------------------
     1. DATA: menu items, deals, reviews
     Each menu item's `topping` field maps to a CSS class
     (topping-classic / topping-veg / topping-nonveg / etc.)
     used to render a pure-CSS pizza graphic — no external
     image files needed, so nothing can ever 404.
  --------------------------------------------------------- */
  const MENU_ITEMS = [
    // ---- Veg Pizzas ----
    { id: 'v1', category: 'veg', veg: true, name: 'Margherita', desc: 'Classic tomato sauce, mozzarella & fresh basil.', price: 249, topping: 'topping-veg' },
    { id: 'v2', category: 'veg', veg: true, name: 'Farmhouse', desc: 'Onion, capsicum, tomato & sweetcorn medley.', price: 329, topping: 'topping-veg' },
    { id: 'v3', category: 'veg', veg: true, name: 'Paneer Tikka', desc: 'Smoky tandoori paneer with peppers & onion.', price: 359, topping: 'topping-veg' },
    { id: 'v4', category: 'veg', veg: true, name: 'Veggie Supreme', desc: 'Loaded with olives, corn, capsicum & mushroom.', price: 379, topping: 'topping-veg' },
    { id: 'v5', category: 'veg', veg: true, name: 'Mushroom Delight', desc: 'Sautéed mushrooms, herbs & extra mozzarella.', price: 339, topping: 'topping-veg' },

    // ---- Non-Veg Pizzas ----
    { id: 'n1', category: 'nonveg', veg: false, name: 'Chicken Pepperoni', desc: 'Classic pepperoni loaded with extra cheese.', price: 399, topping: 'topping-nonveg' },
    { id: 'n2', category: 'nonveg', veg: false, name: 'Chicken BBQ', desc: 'Smoky BBQ chicken with onions & bell peppers.', price: 419, topping: 'topping-nonveg' },
    { id: 'n3', category: 'nonveg', veg: false, name: 'Chicken Supreme', desc: 'Loaded chicken, sausage & fresh veggies.', price: 449, topping: 'topping-nonveg' },
    { id: 'n4', category: 'nonveg', veg: false, name: 'Chicken Tikka', desc: 'Spiced tandoori chicken tikka & onion.', price: 429, topping: 'topping-nonveg' },

    // ---- Premium Pizzas ----
    { id: 'p1', category: 'premium', veg: false, name: 'Meat Lovers Trio', desc: 'Pepperoni, BBQ chicken & smoked sausage.', price: 549, topping: 'topping-premium' },
    { id: 'p2', category: 'premium', veg: true, name: 'Peri Peri Paneer Deluxe', desc: 'Fiery peri-peri paneer with jalapeños.', price: 479, topping: 'topping-premium' },
    { id: 'p3', category: 'premium', veg: false, name: 'Chicken Tikka Deluxe', desc: 'Double chicken tikka, extra cheese, herbs.', price: 529, topping: 'topping-premium' },

    // ---- Sides ----
    { id: 's1', category: 'sides', veg: true, name: 'Garlic Breadsticks', desc: 'Baked fresh with garlic butter & herbs.', price: 149, topping: 'topping-sides' },
    { id: 's2', category: 'sides', veg: true, name: 'Cheesy Dip Sticks', desc: 'Warm breadsticks with a molten cheese dip.', price: 179, topping: 'topping-sides' },
    { id: 's3', category: 'sides', veg: false, name: 'Chicken Wings (6 pc)', desc: 'Crispy wings tossed in spicy glaze.', price: 259, topping: 'topping-sides' },
    { id: 's4', category: 'sides', veg: true, name: 'Potato Wedges', desc: 'Golden wedges with peri-peri seasoning.', price: 139, topping: 'topping-sides' },

    // ---- Desserts ----
    { id: 'd1', category: 'desserts', veg: true, name: 'Choco Lava Cake', desc: 'Warm cake with a molten chocolate centre.', price: 129, topping: 'topping-dessert' },
    { id: 'd2', category: 'desserts', veg: true, name: 'Butterscotch Mousse', desc: 'Light, chilled mousse with butterscotch crunch.', price: 119, topping: 'topping-dessert' },
    { id: 'd3', category: 'desserts', veg: true, name: 'Choco Chip Cookie', desc: 'Freshly baked, gooey chocolate chip cookie.', price: 89, topping: 'topping-dessert' },

    // ---- Beverages ----
    { id: 'b1', category: 'beverages', veg: true, name: 'Coca-Cola (500ml)', desc: 'Chilled and fizzy, served ice-cold.', price: 60, topping: 'topping-bev' },
    { id: 'b2', category: 'beverages', veg: true, name: 'Sprite (500ml)', desc: 'Crisp, refreshing lemon-lime soda.', price: 60, topping: 'topping-bev' },
    { id: 'b3', category: 'beverages', veg: true, name: 'Fresh Lime Soda', desc: 'Sweet or salted, made fresh to order.', price: 79, topping: 'topping-bev' },
  ];

  const DEALS = [
    { id: 'deal1', tag: 'Most Popular', name: 'Buy 1 Get 1 Free', desc: 'Any two medium pizzas from our classic range.', price: 399, mrp: 598, topping: 'topping-classic' },
    { id: 'deal2', tag: 'Family Size', name: 'Family Feast', desc: '2 large pizzas + garlic bread + 1L Coke.', price: 599, mrp: 899, topping: 'topping-nonveg' },
    { id: 'deal3', tag: 'Best Value', name: '2 Medium Pizzas', desc: 'Any 2 medium pizzas, veg or non-veg.', price: 499, mrp: 698, topping: 'topping-veg' },
    { id: 'deal4', tag: 'Weekends Only', name: 'Weekend Special', desc: '1 large pizza + wings + dessert combo.', price: 699, mrp: 949, topping: 'topping-premium' },
  ];

  const REVIEWS = [
    { name: 'Ananya R.', loc: 'Kochi', stars: 5, quote: 'Delivery took under 25 minutes and the pizza was piping hot. The Paneer Tikka is unreal.', initials: 'AR', color: '#0b3d91' },
    { name: 'Rahul M.', loc: 'Bengaluru', stars: 5, quote: 'Best crust in the city, hands down. The Family Feast deal is perfect for movie nights.', initials: 'RM', color: '#e4002b' },
    { name: 'Sneha K.', loc: 'Chennai', stars: 4, quote: 'Loved the Chicken BBQ pizza. Would love a bit more sauce next time, but still fantastic.', initials: 'SK', color: '#1e8a3c' },
    { name: 'Vivek P.', loc: 'Kochi', stars: 5, quote: 'The app-free ordering was so smooth, and the cheesy dip sticks are addictive.', initials: 'VP', color: '#ffc72c' },
  ];

  const CATEGORY_LABELS = {
    veg: 'Veg Pizzas', nonveg: 'Non-Veg Pizzas', premium: 'Premium Pizzas',
    sides: 'Sides', desserts: 'Desserts', beverages: 'Beverages',
  };

  /* Cart state: { itemId: { item, qty } } — in-memory only */
  const cart = {};

  /* ---------------------------------------------------------
     2. HELPERS
  --------------------------------------------------------- */
  function formatINR(amount) {
    return '₹' + amount.toLocaleString('en-IN');
  }

  function buildPizzaGraphic(toppingClass) {
    return `
      <div class="pizza-round crust">
        <div class="pizza-round sauce">
          <div class="pizza-round cheese ${toppingClass}"></div>
        </div>
      </div>`;
  }

  /* ---------------------------------------------------------
     3. RENDER: Deals
  --------------------------------------------------------- */
  function renderDeals() {
    const grid = document.getElementById('dealsGrid');
    grid.innerHTML = DEALS.map(deal => `
      <article class="deal-card">
        <span class="deal-tag">${deal.tag}</span>
        <div class="deal-visual">${buildPizzaGraphic(deal.topping)}</div>
        <h3>${deal.name}</h3>
        <p class="deal-desc">${deal.desc}</p>
        <p class="deal-price">${formatINR(deal.price)} <small>${formatINR(deal.mrp)}</small></p>
        <button type="button" class="btn btn-primary btn-block" data-add-id="${deal.id}">Order Now</button>
      </article>
    `).join('');

    // Deals use the same "add to cart" mechanism as menu items
    grid.querySelectorAll('[data-add-id]').forEach(btn => {
      btn.addEventListener('click', () => {
        const deal = DEALS.find(d => d.id === btn.dataset.addId);
        addToCart({ id: deal.id, name: deal.name, price: deal.price, topping: deal.topping }, btn);
      });
    });
  }

  /* ---------------------------------------------------------
     4. RENDER: Menu (filtered by category)
  --------------------------------------------------------- */
  function renderMenu(category) {
    const grid = document.getElementById('menuGrid');
    const items = MENU_ITEMS.filter(item => item.category === category);

    grid.innerHTML = items.map(item => `
      <article class="menu-card">
        <div class="menu-card-top">
          <div class="menu-card-img">${buildPizzaGraphic(item.topping)}</div>
          <div class="menu-card-heading">
            <p class="menu-card-name">
              <span class="veg-indicator ${item.veg ? '' : 'nonveg'}" aria-hidden="true"></span>
              ${item.name}
            </p>
            <span class="visually-hidden">${item.veg ? 'Vegetarian' : 'Non-vegetarian'}</span>
          </div>
        </div>
        <p class="menu-card-desc">${item.desc}</p>
        <div class="menu-card-bottom">
          <span class="menu-card-price">${formatINR(item.price)}</span>
          <button type="button" class="add-cart-btn" data-add-id="${item.id}">Add to Cart</button>
        </div>
      </article>
    `).join('');

    grid.querySelectorAll('[data-add-id]').forEach(btn => {
      btn.addEventListener('click', () => {
        const item = MENU_ITEMS.find(m => m.id === btn.dataset.addId);
        addToCart(item, btn);
      });
    });
  }

  function setupMenuTabs() {
    const tabs = document.querySelectorAll('.menu-tab');
    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        tabs.forEach(t => { t.classList.remove('active'); t.setAttribute('aria-selected', 'false'); });
        tab.classList.add('active');
        tab.setAttribute('aria-selected', 'true');
        renderMenu(tab.dataset.category);
      });
    });
  }

  /* ---------------------------------------------------------
     5. RENDER: Reviews
  --------------------------------------------------------- */
  function renderReviews() {
    const grid = document.getElementById('reviewsGrid');
    grid.innerHTML = REVIEWS.map(r => `
      <article class="review-card">
        <div class="review-stars" aria-label="${r.stars} out of 5 stars">${'★'.repeat(r.stars)}${'☆'.repeat(5 - r.stars)}</div>
        <p class="review-quote">“${r.quote}”</p>
        <div class="review-author">
          <span class="review-avatar" style="background:${r.color}">${r.initials}</span>
          <span>
            <span class="review-name" style="display:block">${r.name}</span>
            <span class="review-loc">${r.loc}</span>
          </span>
        </div>
      </article>
    `).join('');
  }

  /* ---------------------------------------------------------
     6. CART LOGIC
  --------------------------------------------------------- */
  function addToCart(item, triggerBtn) {
    if (cart[item.id]) {
      cart[item.id].qty += 1;
    } else {
      cart[item.id] = { item, qty: 1 };
    }
    renderCart();
    showToast(`${item.name} added to cart`);

    // Small visual confirmation on the button itself
    if (triggerBtn) {
      const originalText = triggerBtn.textContent;
      triggerBtn.classList.add('just-added');
      triggerBtn.textContent = 'Added ✓';
      setTimeout(() => {
        triggerBtn.classList.remove('just-added');
        triggerBtn.textContent = originalText;
      }, 900);
    }
  }

  function changeQty(itemId, delta) {
    const entry = cart[itemId];
    if (!entry) return;
    entry.qty += delta;
    if (entry.qty <= 0) delete cart[itemId];
    renderCart();
  }

  function removeFromCart(itemId) {
    delete cart[itemId];
    renderCart();
  }

  function getCartCount() {
    return Object.values(cart).reduce((sum, e) => sum + e.qty, 0);
  }

  function getCartSubtotal() {
    return Object.values(cart).reduce((sum, e) => sum + e.qty * e.item.price, 0);
  }

  function renderCart() {
    const list = document.getElementById('cartItemsList');
    const emptyMsg = document.getElementById('cartEmptyMsg');
    const entries = Object.values(cart);

    // Update badge count in header
    document.getElementById('cartCount').textContent = getCartCount();

    if (entries.length === 0) {
      list.innerHTML = '';
      emptyMsg.style.display = 'block';
    } else {
      emptyMsg.style.display = 'none';
      list.innerHTML = entries.map(({ item, qty }) => `
        <li class="cart-item">
          <div class="cart-item-thumb">${buildPizzaGraphic(item.topping)}</div>
          <div>
            <p class="cart-item-name">${item.name}</p>
            <p class="cart-item-price">${formatINR(item.price)} each</p>
            <div class="cart-item-qty">
              <button type="button" class="qty-btn" data-qty-id="${item.id}" data-delta="-1" aria-label="Decrease quantity of ${item.name}">−</button>
              <span aria-live="polite">${qty}</span>
              <button type="button" class="qty-btn" data-qty-id="${item.id}" data-delta="1" aria-label="Increase quantity of ${item.name}">+</button>
            </div>
          </div>
          <div>
            <p class="cart-item-line-total">${formatINR(item.price * qty)}</p>
            <button type="button" class="remove-btn" data-remove-id="${item.id}">Remove</button>
          </div>
        </li>
      `).join('');

      // Wire up qty +/- and remove buttons for this render pass
      list.querySelectorAll('[data-qty-id]').forEach(btn => {
        btn.addEventListener('click', () => changeQty(btn.dataset.qtyId, Number(btn.dataset.delta)));
      });
      list.querySelectorAll('[data-remove-id]').forEach(btn => {
        btn.addEventListener('click', () => removeFromCart(btn.dataset.removeId));
      });
    }

    const subtotal = getCartSubtotal();
    document.getElementById('cartSubtotal').textContent = formatINR(subtotal);
    document.getElementById('cartTotal').textContent = formatINR(subtotal);
    document.getElementById('checkoutBtn').disabled = entries.length === 0;
  }

  /* ---------------------------------------------------------
     7. CART DRAWER open/close
  --------------------------------------------------------- */
  function setupCartDrawer() {
    const drawer = document.getElementById('cartDrawer');
    const backdrop = document.getElementById('cartBackdrop');
    const toggleBtn = document.getElementById('cartToggle');
    const closeBtn = document.getElementById('cartCloseBtn');

    function openCart() {
      drawer.classList.add('is-open');
      backdrop.classList.add('is-open');
      toggleBtn.setAttribute('aria-expanded', 'true');
    }
    function closeCart() {
      drawer.classList.remove('is-open');
      backdrop.classList.remove('is-open');
      toggleBtn.setAttribute('aria-expanded', 'false');
    }

    toggleBtn.addEventListener('click', openCart);
    closeBtn.addEventListener('click', closeCart);
    backdrop.addEventListener('click', closeCart);
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') closeCart();
    });
  }

  /* ---------------------------------------------------------
     8. CHECKOUT (demo only — no payment processed)
  --------------------------------------------------------- */
  function setupCheckout() {
    const checkoutBtn = document.getElementById('checkoutBtn');
    const msg = document.getElementById('checkoutMsg');

    checkoutBtn.addEventListener('click', () => {
      if (getCartCount() === 0) return;
      msg.textContent = 'Demo checkout — no payment is processed. Thanks for trying Slice Corner! 🍕';

      // Clear the cart to simulate a completed order
      Object.keys(cart).forEach(id => delete cart[id]);
      renderCart();

      setTimeout(() => { msg.textContent = ''; }, 5000);
    });
  }

  /* ---------------------------------------------------------
     9. TOAST (small "added to cart" feedback)
  --------------------------------------------------------- */
  let toastTimer = null;
  function showToast(text) {
    const toast = document.getElementById('toast');
    toast.textContent = text;
    toast.classList.add('is-visible');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('is-visible'), 2200);
  }

  /* ---------------------------------------------------------
     10. NAVIGATION: sticky header shadow + mobile hamburger
  --------------------------------------------------------- */
  function setupHeaderScroll() {
    const header = document.getElementById('siteHeader');
    function onScroll() {
      header.classList.toggle('is-scrolled', window.scrollY > 8);
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  function setupMobileNav() {
    const hamburger = document.getElementById('hamburgerBtn');
    const mobileNav = document.getElementById('mobileNav');
    const backdrop = document.getElementById('mobileNavBackdrop');

    function openNav() {
      mobileNav.classList.add('is-open');
      backdrop.classList.add('is-open');
      hamburger.setAttribute('aria-expanded', 'true');
    }
    function closeNav() {
      mobileNav.classList.remove('is-open');
      backdrop.classList.remove('is-open');
      hamburger.setAttribute('aria-expanded', 'false');
    }

    hamburger.addEventListener('click', () => {
      const isOpen = mobileNav.classList.contains('is-open');
      isOpen ? closeNav() : openNav();
    });
    backdrop.addEventListener('click', closeNav);
    mobileNav.querySelectorAll('.nav-link').forEach(link => link.addEventListener('click', closeNav));
  }

  /* Highlight active nav link based on which section is in view */
  function setupScrollSpy() {
    const sections = ['home', 'menu', 'deals', 'about', 'contact']
      .map(id => document.getElementById(id))
      .filter(Boolean);
    const links = document.querySelectorAll('.main-nav .nav-link');

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          links.forEach(link => {
            link.classList.toggle('active', link.getAttribute('href') === `#${entry.target.id}`);
          });
        }
      });
    }, { rootMargin: '-45% 0px -50% 0px' });

    sections.forEach(section => observer.observe(section));
  }

  /* ---------------------------------------------------------
     11. NEWSLETTER (front-end only, no real subscription)
  --------------------------------------------------------- */
  function setupNewsletter() {
    const form = document.getElementById('newsletterForm');
    const emailInput = document.getElementById('newsletterEmail');
    const msg = document.getElementById('newsletterMsg');

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const email = emailInput.value.trim();
      const isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

      if (!isValid) {
        msg.style.color = '#ffe08a';
        msg.textContent = 'Please enter a valid email address.';
        return;
      }
      msg.style.color = '#fff';
      msg.textContent = `Thanks! Deals are on their way to ${email}.`;
      form.reset();
      setTimeout(() => { msg.textContent = ''; }, 5000);
    });
  }

  /* ---------------------------------------------------------
     12. INIT
  --------------------------------------------------------- */
  function init() {
    document.getElementById('footerYear').textContent = new Date().getFullYear();

    renderDeals();
    renderMenu('veg');       // default category shown on load
    renderReviews();
    renderCart();

    setupMenuTabs();
    setupCartDrawer();
    setupCheckout();
    setupHeaderScroll();
    setupMobileNav();
    setupScrollSpy();
    setupNewsletter();
  }

  document.addEventListener('DOMContentLoaded', init);
})();
